[For the updated code click here!](https://github.com/hmkcode/Android/tree/master/android-http/post-json)

