package com.hmkcode.drawing;


import android.app.Activity;

public class MainActivity extends Activity  {

	protected void onCreate(android.os.Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);		
		setContentView(R.layout.activity_main);
	}
	
}
