package com.hmkcode.android.sign;

import android.os.Bundle;
import android.app.Activity;

public class SignInActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_screen);
    }


    
}
